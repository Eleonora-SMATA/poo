﻿package ar.org.centro8.java.curso.tp1_JAVA.cuentas;

import ar.org.centro8.java.curso.tp1_JAVA.clientes.ClienteEmpresa;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)

public class CuentaConvertibilidad extends CuentaCorriente {
    private double saldoDolares;

    public CuentaConvertibilidad(int nroCuenta, double saldo, ClienteEmpresa cliente, double limiteDescubierto,
            double saldoDolares) {
        super(nroCuenta, saldo, cliente, limiteDescubierto);
        this.saldoDolares = saldoDolares;
    }

    /**
     * métodopara depositar dolares
     */
    public void depositarDolares(double monto) {
        setSaldoDolares(getSaldoDolares() + monto);
        System.out.println("Depósito exitoso. Nuevo saldo en Dólares: U$S " + getSaldoDolares());
    }

    /**
     * método para extraer dolares
     */
    public void extraerDolares(double monto) {
        if (monto <= getSaldoDolares()) {
            saldoDolares -= monto;
            System.out.println("Transacción exitosa. Nuevo saldo en dólares: U$S " + saldoDolares);
        } else {
            System.out.println("Saldo insuficiente para extraer el monto solicitado en dólares, ya que su salo en U$$ es: " + saldoDolares);

        }

    }

    public void convertirPesosADolares(double montoPesos, double tasa) {
        if (montoPesos <= getSaldo()) {
            setSaldo(getSaldo() - montoPesos);
            saldoDolares += montoPesos / tasa;
            System.out.println("Conversión exitosa de pesos a dólares: nuevo saldo en dólares: U$S" + saldoDolares
                    + " y su saldo en pesos es de:$ " + getSaldo());

        } else {
            System.out.println("Fondos insuficientes para realizar la conversión.");
        }

    }

    public void convertirDolaresAPesos(double montoDolares, double tasa) {
        if (montoDolares <= saldoDolares) {
            saldoDolares -= montoDolares;
            setSaldo(getSaldo() + montoDolares * tasa);

            System.out.println("Conversión exitosa de dólares a pesos: nuevo saldo dolares: U$S" + getSaldoDolares()
                    + " y su nuevo saldo en pesos es de: $" + getSaldo());
        } else {
            System.out.println("No hay dólares para convertir");
        }

    }

}
