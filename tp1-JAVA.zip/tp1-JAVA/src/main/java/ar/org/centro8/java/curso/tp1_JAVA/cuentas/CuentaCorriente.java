﻿package ar.org.centro8.java.curso.tp1_JAVA.cuentas;

import ar.org.centro8.java.curso.tp1_JAVA.clientes.Cliente;
import ar.org.centro8.java.curso.tp1_JAVA.clientes.ClienteEmpresa;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public abstract class CuentaCorriente extends Cuenta {
    private double limiteDescubierto;

    public CuentaCorriente(int nroCuenta, double saldo, Cliente cliente, double limiteDescubierto) {
        super(nroCuenta, saldo, cliente);
        this.limiteDescubierto = limiteDescubierto;
    }

    @Override
    public void setCliente(Cliente clienteEmpresa) {
        if (clienteEmpresa instanceof ClienteEmpresa) {
            super.setCliente(clienteEmpresa);
        } else {
            System.out.println("No se puede asignar un cliente que no sea cuenta empresa");
        }
    }
    /**
     * método sobreescrito para depositar efectivo
     */
    @Override
    public void depositarEfectivo(double monto) {
        setSaldo(getSaldo() + monto);
        System.out.println("Depósito exitoso. Nuevo saldo: $" + getSaldo());
    }

    /**
     * método sobreescrito para extraer efectivo
     */
    @Override
    public void extraerEfectivo(double monto) {
        if (getSaldo() + limiteDescubierto >= monto) {
            setSaldo(getSaldo() - monto);
            System.out.println("Su extracción ha sido exitosa. Nuevo saldo: $" + getSaldo());
        } else {
            System.out.println("Fondos insuficientes para esta extracción");

        }
    }

    /**
     * método para depositar cheques
     * 
     * @param cheque
     */
    public void depositarCheque(Cheque cheque) {
        setSaldo(getSaldo() + cheque.getMonto());
        System.out.println("Depósito de cheque exitoso. Nuevo saldo: $" + getSaldo());

    }

}
