package ar.org.centro8.java.curso.tp1_JAVA.cuentas;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Cheque {
    private double monto;
    private String bancoEmisor;
    private String fechaPago;


}
