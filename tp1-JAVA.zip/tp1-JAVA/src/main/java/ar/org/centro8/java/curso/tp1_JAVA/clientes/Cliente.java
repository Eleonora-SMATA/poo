package ar.org.centro8.java.curso.tp1_JAVA.clientes;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public abstract class Cliente {
    private int numeroCliente;

}
