package ar.org.centro8.java.curso.tp1_JAVA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp1JavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
