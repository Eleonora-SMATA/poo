package ar.org.centro8.java.curso.tp1_JAVA.test;

import ar.org.centro8.java.curso.tp1_JAVA.clientes.ClienteEmpresa;
import ar.org.centro8.java.curso.tp1_JAVA.clientes.ClienteIndividual;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.CajaDeAhorro;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.Cheque;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.CuentaConvertibilidad;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.CuentaCorriente;

public class Test {
    public static void main(String[] args) {
        // Crear clientes
        ClienteIndividual clienteIndividual1 = new ClienteIndividual(1, "Luciana", "Perez", "20159753");
      		  System.out.println(clienteIndividual1);

        	ClienteEmpresa clienteEmpresa1 = new ClienteEmpresa(2, "Jorgelin", "38426791");
       		 System.out.println(clienteEmpresa1);

        // Crear Caja de Ahorro
        CajaDeAhorro cajaDeAhorro1 = new CajaDeAhorro(1001, 5000, clienteIndividual1, 0.03) {
            @Override
            public void depositarEfectivo(double monto) {
                setSaldo(getSaldo() + monto);
                System.out.println("Depósito exitoso en Caja de Ahorro. Nuevo saldo: $" + getSaldo());
            }
        }; //???


        // Crear Cuenta Corriente
        CuentaCorriente cuentaCorriente1 = new CuentaCorriente(2001, 2000, clienteEmpresa1, 1000) {
            @Override
            public void depositarEfectivo(double monto) {
                setSaldo(getSaldo() + monto);
                System.out.println("Depósito exitoso en Cuenta Corriente. Nuevo saldo: $" + getSaldo());
            }
        };//???

        // Crear Cuenta Convertibilidad
        CuentaConvertibilidad cuentaConvertibilidad1 = new CuentaConvertibilidad(3001, 10000, clienteIndividual1, 2000, 500) {
            @Override
            public void depositarEfectivo(double monto) {
                setSaldo(getSaldo() + monto);
                System.out.println("Depósito de efectivo exitoso en Cuenta Convertibilidad. Nuevo saldo: $" + getSaldo());
            }

            @Override
            public void depositarDolares(double monto) {
                saldoDolares += monto;
                System.out.println("Deposito en dólares exitoso. Nuevo saldo en dólares: $" + saldoDolares);
            }
        };//???


        // Estado inicial
        System.out.println("\n--- Estado inicial ---");
        System.out.println(cajaDeAhorro1);
        System.out.println(cuentaCorriente1);
        System.out.println(cuentaConvertibilidad1);

        // Operaciones Caja de Ahorro
        System.out.println("\n--- Operaciones Caja de Ahorro ---");
        cajaDeAhorro1.depositarEfectivo(1000);
       cajaDeAhorro1.extraerEfectivo(2000);
       cajaDeAhorro1.cobrarInteres();
        System.out.println(cajaDeAhorro1);

        // Operaciones Cuenta Corriente
        System.out.println("\n--- Operaciones Cuenta Corriente ---");
       cuentaCorriente1.depositarEfectivo(500);
        cuentaCorriente1.extraerEfectivo(2500); 
        cuentaCorriente1.extraerEfectivo(1000); 
        System.out.println(cuentaCorriente1);

        // Operaciones Cuenta Convertibilidad
        System.out.println("\n--- Operaciones Cuenta Convertibilidad ---");
        cuentaConvertibilidad1.depositarEfectivo(2000);
        cuentaConvertibilidad1.depositarDolares(300);
        cuentaConvertibilidad1.extraerEfectivo(5000);
        cuentaConvertibilidad1.extraerDolares(600); 
        cuentaConvertibilidad1.convertirPesosADolares(4000, 200); 
        cuentaConvertibilidad1.convertirDolaresAPesos(2, 200);
        System.out.println(cuentaConvertibilidad1);

        // Depositar cheque en cuenta corriente
        System.out.println("\n--- Depósito de Cheque ---");
        Cheque cheque = new Cheque(1500, "Banco Nación", "02/09/2025");
        cuentaConvertibilidad1.depositarCheque(cheque);
        System.out.println(cuentaCorriente1);
    }

}