﻿package ar.org.centro8.java.curso.tp1_JAVA.cuentas;

import ar.org.centro8.java.curso.tp1_JAVA.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public abstract class CuentaConvertibilidad extends CuentaCorriente {
    protected double saldoDolares;

    public CuentaConvertibilidad(int nroCuenta, double saldo, Cliente cliente, double limiteDescubierto,
        double saldoDolares) {
        super(nroCuenta, saldo, cliente, limiteDescubierto);
        this.saldoDolares = saldoDolares;
    }

    /**
     * métodopara depositar dolares
     */

    public abstract void depositarDolares(double monto);

    /**
     * método para extraer dolares
     */
    public void extraerDolares(double monto) {
        if (monto <= getSaldoDolares()) {
            saldoDolares -= monto;
            System.out.println("Transacción exitosa. Nuevo saldo en dólares: U$S" + saldoDolares);
        } else {
            System.out.println("Saldo insuficiente");

        }

    }

    public void convertirPesosADolares(double montoPesos, double tasa) {
        if (montoPesos <= getSaldo()) {
            setSaldo(getSaldo() - montoPesos);
            saldoDolares += montoPesos / tasa;
            System.out.println("Conversión exitosa de pesos a dólares: nuevo saldo en pesos: $" + getSaldo()
                    + ",saldo en dólares: U$S" + saldoDolares);

        } else {
            System.out.println("Fondos insuficientes para realizar la conversión.");
        }

    }

    public void convertirDolaresAPesos(double montoDolares, double tasa) {
        if (montoDolares <= saldoDolares) {
            saldoDolares -= montoDolares;
            setSaldo(getSaldo() + montoDolares * tasa);
            System.out.println("Conversión exitosa de dólares a pesos: nuevo saldo en pesos: $" + getSaldo()
                    + ", saldo en dólares U$S" + saldoDolares);
        } else {
            System.out.println("No hay dólares para convertir");
        }

    }

}
