package ar.org.centro8.java.curso.tp1_JAVA.cuentas;

import ar.org.centro8.java.curso.tp1_JAVA.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public abstract class CuentaConvertibilidad extends CuentaCorriente {
    private double saldoDolares;

    public CuentaConvertibilidad(int nroCuenta, double saldo, Cliente cliente, double limiteDescubierto,
            double saldoDolares) {
        super(nroCuenta, saldo, cliente, limiteDescubierto);
        this.saldoDolares = saldoDolares;
    }

    /**
     * métodopara depositar dolares
     */

    public abstract void depositarDolares(double monto);

    /**
     * método para extraer dolares
     */
    public void extraerDolares(double monto) {
        if (monto <= getSaldoDolares()) {
            System.out.println("Transacción exitosa");
        } else {
            System.out.println("Saldo insuficiente");

        }

    }

    public void convertirPesosADolares(double montoPesos, double tasa) {
        if (montoPesos <= getSaldo()) {
            setSaldo(getSaldo() - montoPesos);
            saldoDolares += montoPesos / tasa;

        } else {
            System.out.println("Fondos insuficientes para realizar la conversión.");
        }

    }

    public void convertirDolaresAPesos(double montoDolares, double tasa) {
        if (montoDolares <= saldoDolares) {
            saldoDolares -= montoDolares;
            setSaldo(getSaldo() + montoDolares * tasa);
        } else {
            System.out.println("No hay dólares para convertir");
        }

    }

}
