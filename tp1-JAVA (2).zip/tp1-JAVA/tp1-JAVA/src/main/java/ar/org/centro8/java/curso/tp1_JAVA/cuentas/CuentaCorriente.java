package ar.org.centro8.java.curso.tp1_JAVA.cuentas;

import ar.org.centro8.java.curso.tp1_JAVA.clientes.Cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)

public abstract class CuentaCorriente extends Cuenta {
    private double limiteDescubierto;

    public CuentaCorriente(int nroCuenta, double saldo, Cliente cliente, double limiteDescubierto) {
        super(nroCuenta, saldo, cliente);
        this.limiteDescubierto = limiteDescubierto;
    }

    @Override
    public void extraerEfectivo(double monto) {
        if (getSaldo() + limiteDescubierto >= monto) {
            System.out.println("Su extracción ha sido exitosa");
        } else {
            System.out.println("Fondos insuficientes para esta extracción");

        }
    }

    /**
     * método para depositar efectivo
     * 
     * @param cheque
     */
    public void depositarCheque(Cheque cheque) {
        setSaldo(getSaldo() + cheque.getMonto());

    }

}
