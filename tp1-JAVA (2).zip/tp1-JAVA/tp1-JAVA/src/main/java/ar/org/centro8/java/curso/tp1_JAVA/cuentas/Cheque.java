package ar.org.centro8.java.curso.tp1_JAVA.cuentas;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

public class Cheque {
    private double monto;
    private String bancoEmisor;
    private String fechaPago;

    public Cheque(double monto, String bancoEmisor, String fechaPago) {
        this.monto = monto;
        this.bancoEmisor = bancoEmisor;
        this.fechaPago = fechaPago;
    }

}
