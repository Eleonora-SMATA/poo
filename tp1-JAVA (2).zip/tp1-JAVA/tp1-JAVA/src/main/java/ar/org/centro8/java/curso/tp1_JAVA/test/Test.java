package ar.org.centro8.java.curso.tp1_JAVA.test;

import ar.org.centro8.java.curso.tp1_JAVA.clientes.ClienteEmpresa;
import ar.org.centro8.java.curso.tp1_JAVA.clientes.ClienteIndividual;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.CajaDeAhorro;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.Cheque;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.CuentaConvertibilidad;
import ar.org.centro8.java.curso.tp1_JAVA.cuentas.CuentaCorriente;

public class Test {
    public static void main(String[] args) {
        ClienteIndividual clienteIndividual1 = new ClienteIndividual(1, "Luciana", "Perez", "20159753");
        System.out.println(clienteIndividual1);

        ClienteEmpresa clienteEmpresa1 = new ClienteEmpresa(2, "Jorgelin", "38426791");
        System.out.println(clienteEmpresa1);

        CajaDeAhorro cajaDeAhorro1 = new CajaDeAhorro(2, 4000, clienteEmpresa1, 30.20);    
        System.out.println(cajaDeAhorro1);

        CuentaCorriente cuentaCorriente1 = new CuentaCorriente(13, 2000, clienteEmpresa1, 1000);
        System.out.println(cuentaCorriente1);

        CuentaConvertibilidad cuentaConvertibilidad1 = new CuentaConvertibilidad(50, 100000, clienteEmpresa1, 5000, 0,
                1500);

        System.out.println(cajaDeAhorro1);
        System.out.println(cuentaCorriente1);
        System.out.println(cuentaConvertibilidad1);

        cajaDeAhorro1.depositarEfectivo(1000);
        System.out.println("Saldo caja ahorro: $"+ cajaDeAhorro1.getSaldo());
        cajaDeAhorro1.extraerEfectivo(5000);
        cajaDeAhorro1.cobrarInteres();
        System.out.println("Saldo caja ahorro: $"+ cajaDeAhorro1.getSaldo());

        cuentaCorriente1.depositarCheque(new Cheque(3500, "Banco Ciudad", "02/05/2025"));
        System.out.println("Saldo cuenta corriente: $"+ cuentaCorriente1.getSaldo());
        cuentaCorriente1.extraerEfectivo(2500);
        System.out.println("Saldo cuenta corriente: $"+ cuentaCorriente1.getSaldo());

        cuentaConvertibilidad1.depositarDolares(700);
        cuentaConvertibilidad1.extraerDolares(700);
        cuentaConvertibilidad1.convertirPesosADolares(5000, 1500);
        cuentaConvertibilidad1.convertirDolaresAPesos(100, 1300);

    }

}
